# Flutter Weather App

A Flutter project where I have created Weather App UI.

## Watch it on YouTube

- [Flutter Weather App UI Tutorial](https://youtu.be/A9EWCl67hKw)

![](https://raw.githubusercontent.com/itzpradip/flutter-weather-app-ui/main/screenshots/weather1.png)
![](https://raw.githubusercontent.com/itzpradip/flutter-weather-app-ui/main/screenshots/weather2.png)
![](https://raw.githubusercontent.com/itzpradip/flutter-weather-app-ui/main/screenshots/weather3.png)
